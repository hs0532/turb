package com.ego.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ego.mapper.TbItemCatMapper;
import com.ego.pojo.TbItemCat;
import com.ego.pojo.TbItemCatExample;
import com.ego.pojo.TreeNode;
import com.ego.pojo.TbItemCatExample.Criteria;
import com.ego.service.ItemCatService;

@Service
public class ItemCatServiceImpl implements ItemCatService {

	@Autowired
	private TbItemCatMapper itemCatMapper;
	@Override
	public List<TreeNode> getItemCatList(long parentId) {
		//根据父id查询子节点数据
		TbItemCatExample example = new TbItemCatExample();
		Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(parentId);
		
		List<TbItemCat> list = itemCatMapper.selectByExample(example);
		List<TreeNode> retList = new ArrayList<TreeNode>();
		//将子节点数据封装到List<TreeNode>
		for(TbItemCat m:list){
			TreeNode node = new  TreeNode();
			node.setId(m.getId());
			node.setText(m.getName());
			node.setState(m.getIsParent()?"closed":"open");
			
			retList.add(node);
		}
		
		return retList;
	}

}
