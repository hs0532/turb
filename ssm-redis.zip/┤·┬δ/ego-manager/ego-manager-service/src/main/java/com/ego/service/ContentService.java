package com.ego.service;

import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbContent;

public interface ContentService {
	public EasyUIDatagrid getContentList(Long categoryId, Integer page,Integer rows);
	
	public EgoResult createContent(TbContent content);
}
