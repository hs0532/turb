package com.ego.service;

import com.ego.pojo.EgoResult;

public interface ItemParamService {
	public EgoResult getItemParamByCid(long cid);
}
