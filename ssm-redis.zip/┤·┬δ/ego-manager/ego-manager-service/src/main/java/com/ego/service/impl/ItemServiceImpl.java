package com.ego.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ego.mapper.TbItemDescMapper;
import com.ego.mapper.TbItemMapper;
import com.ego.mapper.TbItemParamItemMapper;
import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbItem;
import com.ego.pojo.TbItemDesc;
import com.ego.pojo.TbItemExample;
import com.ego.pojo.TbItemParamItem;
import com.ego.service.ItemService;
import com.ego.utils.IDUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	private TbItemMapper itemMapper;
	@Autowired
	private TbItemDescMapper itemDescMapper;
	@Autowired
	private TbItemParamItemMapper itemParamItemMapper;

	@Override
	public EasyUIDatagrid getItemList(int page, int rows) {
		PageHelper.startPage(page, rows); // 在调用mapper文件中statement 之前进行分页
		TbItemExample example = new TbItemExample();
		// GoodsQueryModel gqm =new ..; gqm.setUuid(1) gqm.setName("张")
		// gqm.setPrice(10)
		// Criteria criteria = example.createCriteria();
		// criteria.andTitleLike("shouji") // and title like '手机'
		List<TbItem> list = itemMapper.selectByExample(example);// getByConditon(gqm)

		PageInfo<TbItem> pageInfo = new PageInfo<TbItem>(list);
		EasyUIDatagrid datagrid = new EasyUIDatagrid();
		datagrid.setRows(list);
		datagrid.setTotal(pageInfo.getTotal());

		return datagrid;
	}

	/**
	 * 补齐插入数据库表数据
	 */
	@Override
	public void addItemAndItemDescAndItemParam(TbItem item, String desc, String itemParams) {
		// 插入到tbitem表
		Date date = new Date();
		long itemId = IDUtils.genItemId();
		item.setId(itemId);
		// '商品状态，1-正常，2-下架，3-删除'
		item.setStatus(Byte.valueOf("1"));
		item.setCreated(date);
		item.setUpdated(date);
		
		itemMapper.insert(item);
		// 插入到tbitemdesc
		TbItemDesc itemDesc = new TbItemDesc();
		itemDesc.setItemDesc(desc);
		itemDesc.setItemId(itemId);
		itemDesc.setCreated(date);
		itemDesc.setUpdated(date);
		
		itemDescMapper.insert(itemDesc);
		// 插入到tbitemparamitem
		TbItemParamItem itemParamItem = new TbItemParamItem();
		itemParamItem.setItemId(itemId);
		itemParamItem.setParamData(itemParams);
		itemParamItem.setCreated(date);
		itemParamItem.setUpdated(date);
		
		itemParamItemMapper.insert(itemParamItem);
		return;
	}

}
