package com.ego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ego.mapper.TbContentCategoryMapper;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbContentCategory;
import com.ego.pojo.TbContentCategoryExample;
import com.ego.pojo.TbContentCategoryExample.Criteria;
import com.ego.pojo.TreeNode;
import com.ego.service.ContentCategoryService;

/**
 * 内容分类查询
 * @author Administrator
 *
 */
@Service
public class ContentCategoryServiceImpl implements  ContentCategoryService {

	@Autowired
	private TbContentCategoryMapper categoryMapper;
	/**
	 * 根据当前节点查询自节点
	 */
	@Override
	public List<TreeNode> getContentCategoryList(long id) {
		TbContentCategoryExample example = new TbContentCategoryExample();
		Criteria c = example.createCriteria();
		c.andParentIdEqualTo(id);
		
		List<TbContentCategory> list = this.categoryMapper.selectByExample(example);
		
		List<TreeNode> result = new ArrayList<>();
		for(TbContentCategory content :list){
			TreeNode node = new TreeNode();
			node.setId(content.getId());
			node.setText(content.getName());
			node.setState(content.getIsParent()?"closed":"open");
			result.add(node);
		}
		return result;
	}
	

	
	@Override
	public EgoResult addContentCategory(Long parentId, String name) {
		//在tb_content_catetory新增一条数据
		//补齐数据
		TbContentCategory contentCategory = new TbContentCategory();
		contentCategory.setParentId(parentId);
		contentCategory.setName(name);
		//'状态。可选值:1(正常),2(删除)'
		contentCategory.setStatus(1);
		contentCategory.setSortOrder(1);
		contentCategory.setIsParent(false);
		Date date = new Date();
		contentCategory.setCreated(date);
		contentCategory.setUpdated(date);
		//插入数据
		categoryMapper.insert(contentCategory);
		
		//维护新增节点的父节点isParent信息
//		TbContentCategoryExample example = new TbContentCategoryExample();
//		Criteria criteria = example.createCriteria();
//		criteria.andIdEqualTo(parentId);
		TbContentCategory fatherContentCat = categoryMapper.selectByPrimaryKey(parentId);
		if (!fatherContentCat.getIsParent()) {
			fatherContentCat.setIsParent(true);
			categoryMapper.updateByPrimaryKey(fatherContentCat);
		}
		
		return EgoResult.ok(contentCategory);
	}
	

}
