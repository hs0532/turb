package com.ego.service;

import org.springframework.web.multipart.MultipartFile;

import com.ego.pojo.PictureResult;

public interface PictureService {
	public PictureResult uploadImage(MultipartFile uploadFile);
}
