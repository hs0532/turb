package com.ego.service;

import java.util.List;

import com.ego.pojo.EgoResult;
import com.ego.pojo.TreeNode;

public interface ContentCategoryService {
	public List<TreeNode> getContentCategoryList(long id);
	
	public EgoResult addContentCategory(Long parentId, String name);
}
