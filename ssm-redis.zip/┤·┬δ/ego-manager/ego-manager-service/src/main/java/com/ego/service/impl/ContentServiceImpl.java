package com.ego.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ego.mapper.TbContentCategoryMapper;
import com.ego.mapper.TbContentMapper;
import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbContent;
import com.ego.pojo.TbContentExample;
import com.ego.pojo.TbContentExample.Criteria;
import com.ego.pojo.TbItem;
import com.ego.pojo.TbItemExample;
import com.ego.service.ContentService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class ContentServiceImpl implements ContentService {
	@Autowired
	private TbContentMapper contentMapper;
	
	@Override
	public EasyUIDatagrid getContentList(Long categoryId, Integer page, Integer rows) {
		PageHelper.startPage(page, rows); // 在调用mapper文件中statement 之前进行分页
		TbContentExample example = new TbContentExample();
		Criteria criteria = example.createCriteria();
		criteria.andCategoryIdEqualTo(categoryId);
		List<TbContent> list = contentMapper.selectByExample(example);// 

		PageInfo<TbContent> pageInfo = new PageInfo<TbContent>(list);
		EasyUIDatagrid datagrid = new EasyUIDatagrid();
		datagrid.setRows(list);
		datagrid.setTotal(pageInfo.getTotal());

		return datagrid;
	}

	
	@Override
	public EgoResult createContent(TbContent content) {
		Date date = new Date();
		content.setCreated(date);
		content.setUpdated(date);
		contentMapper.insert(content);
		return EgoResult.ok();
	}

}
