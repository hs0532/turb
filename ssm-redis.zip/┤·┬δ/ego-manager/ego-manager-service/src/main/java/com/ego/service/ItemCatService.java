package com.ego.service;

import java.util.List;

import com.ego.pojo.TreeNode;

public interface ItemCatService {
	public List<TreeNode> getItemCatList(long parentId);
}
