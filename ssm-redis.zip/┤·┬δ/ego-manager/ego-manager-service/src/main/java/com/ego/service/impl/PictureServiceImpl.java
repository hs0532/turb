package com.ego.service.impl;

import java.io.IOException;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ego.pojo.PictureResult;
import com.ego.service.PictureService;
import com.ego.utils.ExceptionUtil;
import com.ego.utils.FtpUtil;
import com.ego.utils.IDUtils;

@Service
public class PictureServiceImpl implements PictureService {

	//@Value注解结合${}会到配置文件取{}中指定参数的参数值
	//#ftp服务器地址
	@Value("${FTP_SERVER_IP_ADDRESS}")
	private String FTP_SERVER_IP_ADDRESS;
	//#ftp服务器端口
	@Value("${FTP_SERVER_PORT}")
	private int FTP_SERVER_PORT;
	//#ftp服务器用户名
	@Value("${FTP_USER_NAME}")
	private String FTP_USER_NAME;
	//#ftp服务器密码
	@Value("${FTP_USER_PASSWORD}")
	private String FTP_USER_PASSWORD;
	//#上传文件ftp根目录
	@Value("${FTP_BASE_PATH}")
	private String FTP_BASE_PATH;
	//#文件回显基础url
	@Value("${HTTP_BASE_URL}")
	private String HTTP_BASE_URL;
	@Override
	public PictureResult uploadImage(MultipartFile uploadFile) {
		//判断uploadFile是否为null,以及size==0,返回提示请上传图片
		if (uploadFile==null) {
			return PictureResult.error("请上传图片");
		}
			//得到后缀名
			String originalFilename = uploadFile.getOriginalFilename();
			String suffix = originalFilename.substring(originalFilename.indexOf("."));
			//得到新的文件名
			String imageName = IDUtils.genImageName();
			//得到今天要上传文件目录
			DateTime dateTime = new DateTime();
			String filePath = dateTime.toString("/yyyy/MM/dd");
			//上传
			try {
				FtpUtil.uploadFile(FTP_SERVER_IP_ADDRESS, FTP_SERVER_PORT, 
						FTP_USER_NAME, FTP_USER_PASSWORD, 
						FTP_BASE_PATH, filePath, imageName+suffix, uploadFile.getInputStream());
				
			} catch (IOException e) {
				e.printStackTrace();
				return PictureResult.error(ExceptionUtil.getStackTrace(e));
			}
		//http://192.168.136.102/  2016/12/06 /
		System.out.println("url==========="+HTTP_BASE_URL+filePath+"/"+imageName+suffix);
		return PictureResult.ok(HTTP_BASE_URL+filePath+"/"+imageName+suffix);
	}

}
