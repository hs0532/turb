package com.ego.service;

import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbItem;

public interface ItemService {
	public EasyUIDatagrid getItemList(int page,int rows);
	
	public void addItemAndItemDescAndItemParam(TbItem item,String desc, String itemParams);
}
