package com.ego.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbItem;
import com.ego.service.ItemService;

@Controller
@RequestMapping("/item")
public class ItemController {
	@Autowired
	private ItemService itemService;
	
	@RequestMapping("/list")
	@ResponseBody
	public EasyUIDatagrid getItemList(Integer page,Integer rows){
		return itemService.getItemList(page, rows);
	}
	
	/**
	 * 添加商品，商品描述，商品规格参数信息
	 * @return
	 */
	@RequestMapping("/save")
	@ResponseBody
	public EgoResult addItemAndItemDescAndItemParam(TbItem item,String desc, String itemParams){
		try {
			itemService.addItemAndItemDescAndItemParam(item, desc, itemParams);
		} catch (Exception e) {
			e.printStackTrace();
			return EgoResult.build(500, "新增商品失败");
		}
		
		return EgoResult.ok();
	}
}
