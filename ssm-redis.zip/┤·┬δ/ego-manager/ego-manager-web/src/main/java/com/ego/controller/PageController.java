package com.ego.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageController {
	@RequestMapping("/")
	public String pageIndex(){
		return "index";
	}
	
//	@RequestMapping("/item-list")
//	public String itemList(){
//		return "item-list";
//	}
//	
//	@RequestMapping("/item-add")
//	public String itemAdd(){
//		return "item-add";
//	}
//	
	@RequestMapping("/{path}")
	public String pageController(@PathVariable String path){
		return path;
	}
}
