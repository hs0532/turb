package com.ego.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ego.pojo.EasyUIDatagrid;
import com.ego.pojo.EgoResult;
import com.ego.pojo.TbContent;
import com.ego.service.ContentService;

@Controller
@RequestMapping("/content")
public class ContentController {
	
	@Autowired
	private ContentService contentService;
	
	@RequestMapping("/query/list")
	@ResponseBody
	public EasyUIDatagrid getContentList(Long categoryId, Integer page,Integer rows){
		return contentService.getContentList(categoryId, page, rows);
	}
	
	@RequestMapping("/save")
	@ResponseBody
	public EgoResult createContent(TbContent content){
		return contentService.createContent(content);
	}
}
