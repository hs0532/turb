package com.ego.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ego.pojo.EgoResult;
import com.ego.pojo.TreeNode;
import com.ego.service.ContentCategoryService;

@Controller
@RequestMapping("/content/category")
public class ContentCategoryController {

	@Autowired
	private ContentCategoryService contentCategoryService;

	@RequestMapping("/list")
	@ResponseBody
	public List<TreeNode> getContentCatList(@RequestParam(value = "id", defaultValue = "0") Long parentId) {
		List<TreeNode> list = contentCategoryService.getContentCategoryList(parentId);//list为parentId对应的字节点集合
		return list;
	}
	
//	url ：
//	/content/category/create
//
//	请求参数
//	parentId:node.parentId,name:node.text
	@RequestMapping("/create")
	@ResponseBody
	public EgoResult addContentCategory(Long parentId, String name){
		return contentCategoryService.addContentCategory(parentId, name);
	}

}
