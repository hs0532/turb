package com.ego.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ego.pojo.PictureResult;
import com.ego.service.PictureService;
import com.ego.utils.JsonUtils;

@Controller
@RequestMapping("/pic")
public class PictureController {
	
	@Autowired
	private PictureService pictureService;
	
	@RequestMapping("/upload")
	@ResponseBody
	public String uploadImage(MultipartFile uploadFile){
		PictureResult result = pictureService.uploadImage(uploadFile);
		//firefox浏览器对富文本编辑器兼容性
		//使用JsonUtils工具将object转为json数据 
		String json = JsonUtils.objectToJson(result);
		return json;
	}
}
