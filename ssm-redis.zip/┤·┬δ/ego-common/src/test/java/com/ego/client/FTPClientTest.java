package com.ego.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.net.ftp.FTPClient;
import org.junit.Test;

public class FTPClientTest {

	@Test
	public void ftp() throws IOException {

		FTPClient ftpClient = new FTPClient();
		ftpClient.connect("192.168.128.128", 21);
		ftpClient.login("ftpuser", "ftpuser");
		FileInputStream inputStream = new FileInputStream(new File("F:/pic/Desert.jpg"));
		ftpClient.changeWorkingDirectory("/home/ftpuser/pic");
		ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
		ftpClient.storeFile("examp.jpg", inputStream);
		ftpClient.logout();
	}
}
