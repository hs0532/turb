package com.ego.pojo;

import java.util.List;

//total   rows
public class EasyUIDatagrid {
	private List<?> rows;
	private long total;
	public List<?> getRows() {
		return rows;
	}
	public void setRows(List<?> rows) {
		this.rows = rows;
	}
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
	}
}
